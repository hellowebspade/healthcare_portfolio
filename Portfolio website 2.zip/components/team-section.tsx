import { Card } from "@/components/ui/card"

const team = [
  {
    name: "Dr. Sarah Johnson",
    role: "Chief Dentist",
    image: "/female-dentist-professional-portrait.jpg",
    specialization: "Cosmetic & General Dentistry",
  },
  {
    name: "Dr. Michael Chen",
    role: "Orthodontist",
    image: "/male-orthodontist-professional-portrait.jpg",
    specialization: "Braces & Aligners",
  },
  {
    name: "Dr. Emily Roberts",
    role: "Endodontist",
    image: "/female-dentist-endodontist-portrait.jpg",
    specialization: "Root Canal Specialist",
  },
  {
    name: "Dr. James Wilson",
    role: "Oral Surgeon",
    image: "/male-oral-surgeon-professional-portrait.jpg",
    specialization: "Dental Implants & Surgery",
  },
]

export function TeamSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-cyan-600 uppercase tracking-wider text-sm mb-4">+ OUR TEAM</p>
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Meet Our Expert Dentists</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our team of highly qualified dental professionals is dedicated to providing you with the best care possible.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow border-none">
              <div className="h-80 bg-cover bg-center" style={{ backgroundImage: `url(${member.image})` }} />
              <div className="p-6 text-center bg-gradient-to-br from-cyan-50 to-white">
                <h3 className="text-xl font-bold text-slate-800 mb-1">{member.name}</h3>
                <p className="text-cyan-600 font-medium mb-2">{member.role}</p>
                <p className="text-gray-600 text-sm">{member.specialization}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
