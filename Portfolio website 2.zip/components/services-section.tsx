import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, Smile, Heart, Scissors } from "lucide-react"

const services = [
  {
    icon: Sparkles,
    title: "Teeth Whitening",
    description: "Professional whitening treatments for a brighter, more confident smile.",
    color: "bg-blue-500",
  },
  {
    icon: Smile,
    title: "Dental Implants",
    description: "Permanent tooth replacement solutions that look and feel natural.",
    color: "bg-cyan-500",
  },
  {
    icon: Heart,
    title: "Root Canal",
    description: "Pain-free root canal treatment to save your natural teeth.",
    color: "bg-pink-500",
  },
  {
    icon: Scissors,
    title: "Orthodontics",
    description: "Braces and aligners to straighten teeth and improve your smile.",
    color: "bg-purple-500",
  },
]

export function ServicesSection() {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-cyan-600 uppercase tracking-wider text-sm mb-4">+ OUR SERVICES</p>
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Comprehensive Dental Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            From routine checkups to advanced treatments, we offer a full range of dental services to keep your smile
            healthy and beautiful.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <Card key={index} className="p-6 hover:shadow-xl transition-shadow border-none">
                <div className={`${service.color} w-16 h-16 rounded-full flex items-center justify-center mb-4`}>
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-800 mb-3">{service.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{service.description}</p>
              </Card>
            )
          })}
        </div>

        <div className="text-center mt-12">
          <Button
            variant="outline"
            className="border-cyan-500 text-cyan-600 hover:bg-cyan-50 rounded-full px-8 bg-transparent"
          >
            View All Services
          </Button>
        </div>
      </div>
    </section>
  )
}
