"use client"

import { useState } from "react"
import { MapPin } from "lucide-react"
import Link from "next/link"

export function Navigation() {
  const [servicesOpen, setServicesOpen] = useState(false)

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-white shadow-sm">
      {/* Top Bar */}
      <div className="bg-cyan-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>A 56 First Floor, Kailash Colony, Greater Kailash, New Delhi - 110048</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Call Us : +91 9555917777 / 011 4650 1777</span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="bg-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="relative w-12 h-12">
                <svg viewBox="0 0 48 48" className="w-full h-full text-cyan-500" fill="currentColor">
                  <path d="M24 4C18 4 13 7 10 12c-2 3-3 7-3 11 0 8 6 14 14 14h6c8 0 14-6 14-14 0-4-1-8-3-11-3-5-8-8-14-8zm0 4c5 0 9 2 11 6 2 3 3 6 3 9 0 6-5 10-11 10h-6c-6 0-11-4-11-10 0-3 1-6 3-9 2-4 6-6 11-6z" />
                  <circle cx="20" cy="20" r="3" />
                  <circle cx="28" cy="20" r="3" />
                  <path d="M18 26c2 3 6 4 8 4s6-1 8-4" />
                </svg>
              </div>
              <div>
                <div className="text-xl font-bold text-cyan-600">stellar smiles</div>
                <div className="text-lg font-semibold text-cyan-500">clinic</div>
              </div>
            </Link>

            {/* Navigation Links */}
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-gray-700 hover:text-cyan-600 font-medium transition-colors">
                Home
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-cyan-600 font-medium transition-colors">
                About Us
              </Link>
              <div className="relative">
                <button
                  onMouseEnter={() => setServicesOpen(true)}
                  onMouseLeave={() => setServicesOpen(false)}
                  className="text-gray-700 hover:text-cyan-600 font-medium transition-colors flex items-center gap-1"
                >
                  Services
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
                {servicesOpen && (
                  <div
                    onMouseEnter={() => setServicesOpen(true)}
                    onMouseLeave={() => setServicesOpen(false)}
                    className="absolute top-full left-0 mt-2 w-48 bg-white shadow-lg rounded-lg py-2"
                  >
                    <Link href="/services/general" className="block px-4 py-2 hover:bg-cyan-50 transition-colors">
                      General Dentistry
                    </Link>
                    <Link href="/services/cosmetic" className="block px-4 py-2 hover:bg-cyan-50 transition-colors">
                      Cosmetic Dentistry
                    </Link>
                    <Link href="/services/orthodontics" className="block px-4 py-2 hover:bg-cyan-50 transition-colors">
                      Orthodontics
                    </Link>
                  </div>
                )}
              </div>
              <Link href="/team" className="text-gray-700 hover:text-cyan-600 font-medium transition-colors">
                Our Team
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-cyan-600 font-medium transition-colors">
                Contact Us
              </Link>
            </nav>
          </div>
        </div>
      </div>
    </div>
  )
}
