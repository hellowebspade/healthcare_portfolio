import Link from "next/link"
import { MapPin, Phone, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="relative w-10 h-10">
                <svg viewBox="0 0 48 48" className="w-full h-full text-cyan-400" fill="currentColor">
                  <path d="M24 4C18 4 13 7 10 12c-2 3-3 7-3 11 0 8 6 14 14 14h6c8 0 14-6 14-14 0-4-1-8-3-11-3-5-8-8-14-8zm0 4c5 0 9 2 11 6 2 3 3 6 3 9 0 6-5 10-11 10h-6c-6 0-11-4-11-10 0-3 1-6 3-9 2-4 6-6 11-6z" />
                  <circle cx="20" cy="20" r="3" />
                  <circle cx="28" cy="20" r="3" />
                  <path d="M18 26c2 3 6 4 8 4s6-1 8-4" />
                </svg>
              </div>
              <div>
                <div className="text-lg font-bold text-cyan-400">stellar smiles</div>
                <div className="text-md font-semibold text-cyan-300">clinic</div>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              South Delhi's trusted name in advanced and compassionate dental care.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/team" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Our Team
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/services/whitening" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Teeth Whitening
                </Link>
              </li>
              <li>
                <Link href="/services/implants" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Dental Implants
                </Link>
              </li>
              <li>
                <Link href="/services/root-canal" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Root Canal
                </Link>
              </li>
              <li>
                <Link href="/services/orthodontics" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Orthodontics
                </Link>
              </li>
              <li>
                <Link href="/services/cosmetic" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  Cosmetic Dentistry
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-cyan-400 flex-shrink-0 mt-1" />
                <span className="text-gray-400 text-sm">
                  A 56 First Floor, Kailash Colony, Greater Kailash, New Delhi - 110048
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-cyan-400" />
                <span className="text-gray-400 text-sm">+91 9555917777</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-cyan-400" />
                <span className="text-gray-400 text-sm">info@stellarsmilesclinic.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">© 2025 Stellar Smiles Clinic. All rights reserved.</p>
            <div className="flex gap-6">
              <Link href="/privacy" className="text-gray-400 hover:text-cyan-400 text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-cyan-400 text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
