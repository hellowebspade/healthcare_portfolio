import { Button } from "@/components/ui/button"
import { ArrowRight, Plus } from "lucide-react"

export function AboutSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image Collage */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div
                  className="h-48 rounded-lg bg-cover bg-center"
                  style={{
                    backgroundImage: "url(/placeholder.svg?height=300&width=300&query=dental+clinic+reception+area)",
                  }}
                />
                <div
                  className="h-64 rounded-lg bg-cover bg-center"
                  style={{
                    backgroundImage: "url(/placeholder.svg?height=400&width=300&query=modern+dental+chair+equipment)",
                  }}
                />
              </div>
              <div className="space-y-4 mt-8">
                <div
                  className="h-64 rounded-lg bg-cover bg-center"
                  style={{
                    backgroundImage: "url(/placeholder.svg?height=400&width=300&query=dentist+examining+patient)",
                  }}
                />
                <div
                  className="h-48 rounded-lg bg-cover bg-center"
                  style={{
                    backgroundImage: "url(/placeholder.svg?height=300&width=300&query=dental+clinic+interior)",
                  }}
                />
              </div>
            </div>

            {/* Badge */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-cyan-500 text-white rounded-full w-32 h-32 flex flex-col items-center justify-center shadow-xl">
              <div className="text-3xl font-bold">15+</div>
              <div className="text-xs text-center">
                Years of
                <br />
                Experience
              </div>
            </div>

            {/* Decorative Plus */}
            <Plus className="absolute -bottom-4 -left-4 h-16 w-16 text-cyan-500" strokeWidth={1} />
          </div>

          {/* Content */}
          <div>
            <p className="text-cyan-600 uppercase tracking-wider text-sm mb-4">+ ABOUT US</p>
            <h2 className="text-4xl font-bold text-slate-800 mb-6">
              Your Trusted
              <br />
              Stellar Smiles Clinic
            </h2>
            <p className="text-gray-600 leading-relaxed mb-6">
              Welcome to Stellar Smiles Clinic, South Delhi's trusted name in advanced and compassionate dental care.
              With a reputation built on precision, ethics, and patient satisfaction, we're proud to be one of the most
              sought-after dental clinics in the region. Our expert team of dental professionals combines years of
              experience with the latest technology to deliver exceptional results — all in a warm, relaxing
              environment. At Stellar Smiles, we believe that a healthy smile is a powerful asset. Whether you're coming
              in for routine care, cosmetic enhancements, or specialized treatments, you can expect personalized
              attention, transparent advice, and truly pain-free dentistry. Join the thousands of patients who trust us
              with their smiles — and discover why Stellar Smiles Clinic is redefining modern dental excellence in South
              Delhi.
            </p>
            <Button className="bg-cyan-500 hover:bg-cyan-600 text-white rounded-full px-6">
              Read More About Us
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
