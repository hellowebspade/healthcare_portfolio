"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

export function ContactSection() {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-cyan-600 uppercase tracking-wider text-sm mb-4">+ CONTACT US</p>
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Get In Touch With Us</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Have questions or ready to schedule an appointment? We'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-6">
            <Card className="p-6 flex items-start gap-4 border-none shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-cyan-500 text-white p-3 rounded-full">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800 mb-2">Our Location</h3>
                <p className="text-gray-600">A 56 First Floor, Kailash Colony, Greater Kailash, New Delhi - 110048</p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4 border-none shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-cyan-500 text-white p-3 rounded-full">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800 mb-2">Phone Numbers</h3>
                <p className="text-gray-600">
                  +91 9555917777
                  <br />
                  011 4650 1777
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4 border-none shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-cyan-500 text-white p-3 rounded-full">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800 mb-2">Working Hours</h3>
                <p className="text-gray-600">
                  Monday to Saturday
                  <br />
                  10:00 AM to 7:00 PM
                </p>
              </div>
            </Card>

            <Card className="p-6 flex items-start gap-4 border-none shadow-md hover:shadow-lg transition-shadow">
              <div className="bg-cyan-500 text-white p-3 rounded-full">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800 mb-2">Email Address</h3>
                <p className="text-gray-600">info@stellarsmilesclinic.com</p>
              </div>
            </Card>
          </div>

          {/* Contact Form */}
          <Card className="p-8 border-none shadow-lg">
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                  <Input placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                  <Input placeholder="Doe" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <Input type="email" placeholder="john.doe@example.com" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <Input type="tel" placeholder="+91 9555917777" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <Textarea placeholder="Tell us about your dental concerns..." rows={5} />
              </div>

              <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-white rounded-full py-6">
                Send Message
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </section>
  )
}
